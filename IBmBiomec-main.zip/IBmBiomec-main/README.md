# Disciplina USP de Biomecânica para Informática Biomédica 

## O sistema de referência 2D foi adotado conforme a Figura 1:

![Figura 1. Calibrador 2D.](docs/ref2d_guide.png)

|     |   x   |   y   |
|-----|-------|-------|
| p1  | 0.000 | 0.000 |
| p2  | 1.466 | 0.000 |
| p3  | 0.000 | 0.450 |
| p4  | 1.466 | 0.447 |
| p5  | 0.000 | 0.903 |
| p6  | 1.466 | 0.902 |


## O sistema de referência 3D foi adotado conforme a Figura 2:

![Figura 2. Calibrador 3D.](docs/ref3d_guide.png)

|     |   x   |   y   |   z   |
|-----|-------|-------|-------|
| p1  | 0.000 | 0.000 | 0.000 |
| p2  | 0.000 | 1.466 | 0.000 |
| p3  | 0.781 | 1.466 | 0.000 |
| p4  | 0.781 | 0.000 | 0.000 |
| p5  | 0.000 | 0.000 | 0.453 |
| p6  | 0.000 | 1.466 | 0.451 |
| p7  | 0.781 | 1.466 | 0.447 |  
| p8  | 0.781 | 0.000 | 0.450 |
| p9  | 0.000 | 0.000 | 0.907 |
| p10 | 0.000 | 1.466 | 0.903 |
| p11 | 0.781 | 1.466 | 0.902 |
| p12 | 0.781 | 0.000 | 0.903 |

* Continuar: extrair as coordenadas de tela em pixel para realizar a calibração 2D.
